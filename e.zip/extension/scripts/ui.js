
var UI;
(function (UI) {
    var REFRESH_TIMEOUT = 500;

    (function (View) {
        View[View["ROSTER"] = 0] = "ROSTER";
        View[View["ACCESS"] = 1] = "ACCESS";
        View[View["OPTIONS"] = 2] = "OPTIONS";
        View[View["CHAT"] = 3] = "CHAT";
    })(UI.View || (UI.View = {}));
    var View = UI.View;

    

    

    

    

    var UserInterface = (function () {
        function UserInterface(core, notify) {
            var _this = this;
            this.core = core;
            this.notify = notify;
            this.DEBUG = false;
            this.network = 'google';
            this.user = null;
            this.instance = null;
            this.proxy = null;
            this.notifications = 0;
            this.advancedOptions = false;
            this.search = '';
            this.numClients = 0;
            this.myName = '';
            this.myPic = null;
            this.isProxying = false;
            this.accessIds = 0;
            this.oldDescription = '';
            this.filters = {
                'online': true,
                'myAccess': false,
                'friendsAccess': false,
                'uproxy': false
            };
            this.update = function (type, data) {
            };
            this.isSplash = function () {
                return _this.toggles.splash || !_this.loggedIn();
            };
            this.isRoster = function () {
                return 0 /* ROSTER */ == _this.view;
            };
            this.isAccess = function () {
                return 1 /* ACCESS */ == _this.view;
            };
            this.refreshTimer = null;
            this.refreshNeeded = false;
            this.refreshFunction_ = function () {
                console.warn('Angular has not hooked into UI refresh!');
            };
            this.refreshDOM = function () {
                if (!_this.refreshFunction_) {
                    return;
                }
                if (_this.refreshTimer) {
                    _this.refreshNeeded = true;
                } else {
                    _this.refreshFunction_();
                    _this.refreshNeeded = false;

                    _this.refreshTimer = setTimeout(function () {
                        _this.refreshTimer = null;
                        if (_this.refreshNeeded) {
                            _this.refreshDOM();
                        }
                        _this.refreshNeeded = false;
                    }, REFRESH_TIMEOUT);
                }
            };
            this.setRefreshHandler = function (f) {
                _this.refreshDOM = function () {
                    f();
                };
            };
            this.setClients = function (numClients) {
                _this.numClients = numClients;
                if (numClients > 0) {
                    _this.notify.setColor('#008');
                    _this.notify.setLabel('↓');
                } else {
                    _this.notify.setColor('#800');
                }
            };
            this.startProxying = function () {
                if (!_this.user || !_this.instance) {
                    console.warn('Cannot stop proxying without a current instance.');
                }

                var path = {
                    network: 'google',
                    userId: _this.user.userId,
                    instanceId: _this.instance.instanceId
                };
                _this.core.start(path).then(function () {
                    _this.proxy = _this.instance;
                    _this._setProxying(true);
                });
            };
            this.stopProxying = function () {
                if (!_this.instance) {
                    console.warn('Stop Proxying called while not proxying.');
                    return;
                }
                _this._setProxying(false);
                _this.core.stop();
            };
            this._setProxying = function (isProxying) {
                _this.isProxying = isProxying;
                if (isProxying) {
                    _this.notify.setIcon('uproxy-19-p.png');
                } else {
                    _this.notify.setIcon('uproxy-19.png');
                }
            };
            this.toggleFilter = function (filter) {
                if (undefined === _this.filters[filter]) {
                    console.error('Filter "' + filter + '" is not a valid filter.');
                    return false;
                }
                console.log('Toggling ' + filter + ' : ' + _this.filters[filter]);
                _this.filters[filter] = !_this.filters[filter];
            };
            this.contactIsFiltered = function (user) {
                var searchText = _this.search, compareString = user.name.toLowerCase();

                if ((_this.filters.online && !user.online) || (_this.filters.uproxy && !user.canUProxy) || (_this.filters.myAccess && !user.givesMe) || (_this.filters.friendsAccess && !user.usesMe)) {
                    return true;
                }

                if (!searchText) {
                    return false;
                }
                if (compareString.indexOf(searchText) >= 0) {
                    return false;
                }
                return true;
            };
            this.focusOnUser = function (user) {
                _this.view = 1 /* ACCESS */;
                console.log('focusing on user ' + user);
                _this.user = user;
                _this.dismissNotification(user);

                if (user.instances.length > 0) {
                    _this.instance = user.instances[0];
                }
            };
            this.returnToRoster = function () {
                _this.view = 0 /* ROSTER */;
                console.log('returning to roster! ' + _this.user);
                if (_this.user && _this.user.hasNotification) {
                    console.log('sending notification seen');
                    _this.dismissNotification(_this.user);
                    _this.user = null;
                }
            };
            this.setNotifications = function (n) {
                _this.notify.setLabel(n > 0 ? n : '');
                _this.notifications = n < 0 ? 0 : n;
            };
            this.decNotifications = function () {
                _this.setNotifications(_this.notifications - 1);
            };
            this.dismissNotification = function (user) {
                if (!user.hasNotification) {
                    return;
                }
                _this.core.dismissNotification(user.userId);
                user.hasNotification = false;
                _this.decNotifications();
            };
            this.syncInstance = function (instance) {
            };
            this.updateMappings = function () {
            };
            this.updateIdentity = function (identity) {
            };
            this.sendConsent = function () {
            };
            this.addNotification = function () {
            };
            this.syncNetwork_ = function (network) {
                console.log('uProxy.Update.NETWORK', network, model.networks);
                console.log(model);
                if (!(network.name in model.networks)) {
                    model.networks[network.name] = {
                        name: network.name,
                        online: network.online,
                        roster: {}
                    };
                } else {
                    model.networks[network.name].online = network.online;
                }
            };
            this.loggedIn = function () {
                for (var networkId in model.networks) {
                    if (model.networks[networkId].online) {
                        return true;
                    }
                }
                return false;
            };
            this.syncUser = function (payload) {
                var network = model.networks[payload.network];
                if (!network) {
                    console.warn('Received USER for non-existing network.');
                    return;
                }

                var profile = payload.user;

                var user;
                user = network.roster[profile.userId];
                if (!user) {
                    user = new UI.User(profile.userId);
                    network.roster[profile.userId] = user;
                    model.roster[profile.userId] = user;
                }
                user.update(profile);
                user.refreshStatus(payload.clients);
                user.setInstances(payload.instances);

                if (_this.user === user) {
                    _this.instance = user.instances[0];
                }
                console.log('Synchronized user.', user);
                _this.refreshDOM();
            };
            this.login = function (network) {
                _this.core.login(network).then(function () {
                    _this.view = 0 /* ROSTER */;
                    _this.toggles.splash = false;
                }, function () {
                    console.warn('login failed for ' + network);
                });
            };
            this.sync = function (previousPatch) {
            };
            this.view = 0 /* ROSTER */;
            this.toggles = {
                splash: true,
                options: false,
                search: true
            };

            core.onUpdate(2000 /* ALL */, function (state) {
                console.log('Received uProxy.Update.ALL:', state);
            });

            core.onUpdate(2001 /* NETWORK */, this.syncNetwork_);

            core.onUpdate(2002 /* USER_SELF */, function (payload) {
                console.log('uProxy.Update.USER_SELF:', payload);
                var profile = payload.user;
                _this.myPic = profile.imageData;
                _this.myName = profile.name;
            });
            core.onUpdate(2003 /* USER_FRIEND */, function (payload) {
                console.log('uProxy.Update.USER_FRIEND:', payload);
                _this.syncUser(payload);
            });

            console.log('Created the UserInterface');
        }
        return UserInterface;
    })();
    UI.UserInterface = UserInterface;
})(UI || (UI = {}));
