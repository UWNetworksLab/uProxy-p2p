var UPROXY_CHROME_APP_ID = 'fmdppkkepalnkeommjadgbhiohihdhii';
var SYNC_TIMEOUT = 1000;

;

var ChromeCoreConnector = (function () {
    function ChromeCoreConnector(options_) {
        var _this = this;
        this.options_ = options_;
        this.promiseId_ = 1;
        this.mapPromiseIdToFulfillAndReject_ = {};
        this.connect = function () {
            console.log('trying to connect to app');
            if (_this.status.connected) {
                console.warn('Already connected.');
                return Promise.resolve();
            }

            return _this.connect_().then(_this.flushQueue).then(function () {
                for (var type in _this.listeners_) {
                    var payload = {
                        cmd: 'on',
                        type: parseInt(type, 10)
                    };
                    console.log('Connecting listener for', JSON.stringify(payload));
                    _this.send_(payload);
                }

                _this.sendCommand(1000 /* READY */);
            });
        };
        this.connect_ = function () {
            _this.appPort_ = chrome.runtime.connect(_this.appId_, _this.options_);
            if (!_this.appPort_) {
                console.warn('connect_: Unable to connect to create this.appPort_.');

                _this.onDisconnectHandler_();
                return Promise.reject(new Error('Unable to connect to App.'));
            }

            _this.appPort_.onDisconnect.addListener(_this.onDisconnectHandler_);

            return new Promise(function (F, R) {
                var ackResponse = function (msg) {
                    console.log('connect_: in ackResponse');
                    if (ChromeGlue.ACK !== msg) {
                        R(new Error('Unexpected msg from uProxy App: ' + msg));
                    }

                    console.log(_this.appPort_);
                    _this.appPort_.onMessage.removeListener(ackResponse);
                    _this.appPort_.onMessage.addListener(_this.receive_);
                    _this.status.connected = true;
                    F(_this.appPort_);
                };
                _this.appPort_.onMessage.addListener(ackResponse);

                _this.appPort_.postMessage(ChromeGlue.CONNECT);
            }).catch(function (e) {
                console.log(e);

                _this.onDisconnectHandler_();
                return Promise.reject(new Error('Unable to connect to uProxy App.'));
            });
        };
        this.onDisconnectHandler_ = function () {
            console.log('Disconnected from app, previous status was ' + _this.status.connected);

            _this.status.connected = false;
            _this.appPort_ = null;

            console.warn('Retrying connection in ' + (SYNC_TIMEOUT / 1000) + 's...');
            setTimeout(_this.connect, SYNC_TIMEOUT);
        };
        this.onUpdate = function (update, handler) {
            var type = '' + update;
            if (!(type in _this.listeners_)) {
                _this.listeners_[type] = [];
            }
            _this.listeners_[type].push(handler);
            var payload = {
                cmd: 'on',
                type: update
            };
            console.log('UI onUpdate for', JSON.stringify(payload));
            _this.send_(payload, true);
        };
        this.sendCommand = function (command, data) {
            var payload = {
                cmd: 'emit',
                type: command,
                data: data,
                promiseId: 0
            };
            console.log('UI sending Command ' + JSON.stringify(payload));
            _this.send_(payload);
        };
        this.promiseCommand = function (command, data) {
            var promiseId = ++(_this.promiseId_);
            var payload = {
                cmd: 'emit',
                type: command,
                data: data,
                promiseId: promiseId
            };
            console.log('UI sending Promise Command ' + JSON.stringify(payload));

            var fulfillFunc;
            var rejectFunc;
            var promise = new Promise(function (F, R) {
                fulfillFunc = F;
                rejectFunc = R;
            });

            _this.mapPromiseIdToFulfillAndReject_[promiseId] = {
                fulfill: fulfillFunc,
                reject: rejectFunc
            };

            _this.send_(payload);

            return promise;
        };
        this.handleRequestFulfilled_ = function (promiseId) {
            console.log('promise command fulfilled ' + promiseId);
            if (_this.mapPromiseIdToFulfillAndReject_[promiseId]) {
                _this.mapPromiseIdToFulfillAndReject_[promiseId].fulfill();
                delete _this.mapPromiseIdToFulfillAndReject_[promiseId];
            } else {
                console.warn('fulfill not found ' + promiseId);
            }
        };
        this.handleRequestRejected_ = function (promiseId) {
            console.log('promise command rejected ' + promiseId);
            if (_this.mapPromiseIdToFulfillAndReject_[promiseId]) {
                _this.mapPromiseIdToFulfillAndReject_[promiseId].reject();
                delete _this.mapPromiseIdToFulfillAndReject_[promiseId];
            } else {
                console.warn('reject not found ' + promiseId);
            }
        };
        this.send_ = function (payload, skipQueue) {
            if (typeof skipQueue === "undefined") { skipQueue = false; }
            if (!_this.status.connected || null == _this.appPort_) {
                if (!skipQueue) {
                    _this.queue_.push(payload);
                }
                return;
            }
            try  {
                _this.appPort_.postMessage(payload);
            } catch (e) {
                console.warn(e);
                console.warn('ChromeCoreConnector.send_ postMessage failure.');
            }
        };
        this.receive_ = function (msg) {
            if (msg.type in _this.listeners_) {
                var handlers = _this.listeners_[msg.type].slice(0);
                handlers.forEach(function (handler) {
                    handler(msg.data);
                });
            }
        };
        this.flushQueue = function (port) {
            while (0 < _this.queue_.length) {
                if (!_this.status.connected) {
                    console.warn('Disconnected from App whilst flushing queue.');
                    break;
                }
                var payload = _this.queue_.shift();
                _this.send_(payload);
            }
            return port;
        };
        this.reset = function () {
            console.log('Resetting.');
            _this.sendCommand(1002 /* RESET */, null);
        };
        this.sendInstance = function (clientId) {
            _this.sendCommand(1005 /* SEND_INSTANCE */, clientId);
        };
        this.modifyConsent = function (command) {
            console.log('Modifying consent.', command);
            _this.sendCommand(1012 /* MODIFY_CONSENT */, command);
        };
        this.start = function (path) {
            console.log('Starting to proxy through ' + path);
            return _this.promiseCommand(1010 /* START_PROXYING */, path).then(function () {
                proxyConfig.startUsingProxy();
            });
        };
        this.stop = function () {
            console.log('Stopping proxy session.');
            _this.sendCommand(1011 /* STOP_PROXYING */);
            proxyConfig.stopUsingProxy();
        };
        this.updateDescription = function (description) {
            console.log('Updating description to ' + description);
            _this.sendCommand(1008 /* UPDATE_DESCRIPTION */, description);
        };
        this.changeOption = function (option) {
            console.log('Changing option ' + option);
        };
        this.login = function (network) {
            return _this.promiseCommand(1003 /* LOGIN */, network);
        };
        this.logout = function (network) {
            _this.sendCommand(1004 /* LOGOUT */, network);
        };
        this.dismissNotification = function (userId) {
            _this.sendCommand(1009 /* DISMISS_NOTIFICATION */, userId);
        };
        this.appId_ = UPROXY_CHROME_APP_ID;
        this.status = { connected: false };
        this.appPort_ = null;
        this.queue_ = [];
        this.listeners_ = {};

        this.onUpdate(2008 /* COMMAND_FULFILLED */, this.handleRequestFulfilled_);
        this.onUpdate(2009 /* COMMAND_REJECTED */, this.handleRequestRejected_);
    }
    return ChromeCoreConnector;
})();
