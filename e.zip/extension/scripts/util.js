var FSM = (function () {
    function FSM() {
        var _this = this;
        this.table = {};
        this.set = function (start, transition, dest) {
            var startIndex = start;
            var transitionIndex = transition;
            if (!(startIndex in _this.table)) {
                _this.table[startIndex] = {};
            }
            _this.table[startIndex][transitionIndex] = dest;
        };
        this.get = function (start, transition) {
            var startIndex = start;
            var transitionIndex = transition;
            if (!(startIndex in _this.table)) {
                return null;
            }
            if (!(transitionIndex in _this.table[startIndex])) {
                return null;
            }
            return _this.table[startIndex][transitionIndex];
        };
    }
    return FSM;
})();

function linear_congruence_gen(prior) {
    return (1 + prior * 16807) % 2147483647;
}

function list_erase(list, obj_to_remove) {
    var index = list.indexOf(obj_to_remove);
    if (index < 0) {
        return list;
    } else {
        return list.splice(index, 1);
    }
}

function restrictKeys(template, input) {
    var output = {}, err;
    for (var k in template) {
        if (input && k in input) {
            output[k] = cloneDeep(input[k]);
        } else if (template[k] !== null) {
            output[k] = cloneDeep(template[k]);
        } else {
            err = new Error('Missing required key ' + k + '.\nObject: ' + JSON.stringify(input, null, '  ') + '\nRestriction: ' + JSON.stringify(template, null, '  '));
            console.error("Failed object-restrict on " + err.stack);
            throw err;
        }
    }
    var restricted_keys = Object.keys(template);
    var object_keys = Object.keys(input);
    var excess_keys = restricted_keys.reduce(function (prev, elem) {
        if (restricted_keys.indexOf(elem) < 0) {
            prev.push(prev);
            return prev;
        } else {
            return prev;
        }
    }, []);
    if (excess_keys.length > 0) {
        err = new Error('Excess members in object:' + excess_keys + '\nObject: ' + JSON.stringify(input, null, '  ') + '\nRestriction: ' + JSON.stringify(template, null, '  '));
        console.error("Failed object-restrict on " + err.stack);
        throw err;
    }
    return output;
}

function makeLogger(level) {
    var logFunc = console[level];
    if (logFunc) {
        return logFunc.bind(console);
    }
    return function () {
        var s = '[' + level.toUpperCase() + '] ';
        for (var i = 0, ii = arguments[i]; i < arguments.length; s += ii + ' ', ii = arguments[++i]) {
            ii = typeof ii === 'string' ? ii : ii instanceof Error ? ii.toString() : JSON.stringify(ii);
        }
        console.log(s);
    };
}

function isUndefined(val) {
    return typeof val == 'undefined';
}

function isDefined(val) {
    return typeof val != 'undefined';
}

function cloneDeep(val) {
    return JSON.parse(JSON.stringify(val));
}

function getKeyWithDefault(object, key, def) {
    if (object[key] !== undefined) {
        return object[key];
    } else {
        return def;
    }
}

function extractCryptoKey(sdpHeaders) {
    var lines = sdpHeaders.split(/\r?\n/), currentLine, midDataFound = false, keyParams, keyParam, i, j;

    for (i in lines) {
        currentLine = lines[i];
        if (!midDataFound) {
            if (currentLine === 'a=mid:data') {
                midDataFound = true;
            }
        } else {
            if (0 === currentLine.indexOf('a=crypto:1')) {
                keyParams = currentLine.substring(currentLine.indexOf(" ", 11) + 1).split(" ");
                for (j in keyParams) {
                    keyParam = keyParams[j];
                    if (keyParam.indexOf('inline:') === 0) {
                        return keyParam.substring(7);
                    }
                }
            }
        }
    }

    return null;
}

function valuesOf(dict) {
    return Object.keys(dict).map(function (key) {
        return dict[key];
    });
}
