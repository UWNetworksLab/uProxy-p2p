angular.module('UProxyExtension-popup', ['UProxyExtension']).controller('MainCtrl', [
    '$scope', function ($scope) {
        var ui = $scope.ui;
        var core = $scope.core;

        $scope.filterTips = {
            'uproxy': 'Only show contacts with UProxy installed.',
            'myAccess': 'Show contacts who provide me access.',
            'friendsAccess': 'Show contacts who use me for access.',
            'online': 'Only show online contacts.'
        };

        $scope.updateSortedContacts = function () {
            $scope.alphabeticalContacts = [];
        };

        $scope.toggleOptions = function () {
            console.log('Viewing splash page');
            ui.toggles.splash = !ui.toggles.splash;
        };

        $scope.toggleSearch = function () {
            ui.toggles.search = !ui.toggles.search;
        };

        $scope.showFilter = function (filter) {
            $scope.filterTip = $scope.filterTips[filter];
            $scope.showFilterTip = true;
        };

        $scope.login = function (network) {
            ui.login(network);
        };
    }]);
