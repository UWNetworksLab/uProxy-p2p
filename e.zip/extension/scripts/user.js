var UI;
(function (UI) {
    var User = (function () {
        function User(userId) {
            var _this = this;
            this.userId = userId;
            this.online = false;
            this.canUProxy = false;
            this.givesMe = false;
            this.usesMe = false;
            this.hasNotification = false;
            this.update = function (profile) {
                if (_this.userId !== profile.userId) {
                    console.error('Unexpected userId: ' + profile.userId);
                }
                _this.name = profile.name;
                _this.url = profile.url;
                _this.imageData = profile.imageData;
            };
            this.refreshStatus = function (statuses) {
                _this.online = statuses.some(function (status) {
                    return 0 /* OFFLINE */ !== status;
                });

                _this.canUProxy = statuses.some(function (status) {
                    return 1 /* ONLINE */ === status;
                });
                console.log('Updated ' + _this.name + ' - known to be: ' + '\n online: ' + _this.online + '\n uproxy-enabled: ' + _this.canUProxy);
            };
            this.setInstances = function (instances) {
                _this.instances = instances;
            };
            console.log('new user: ' + this.userId);
            this.name = '';
            this.clients = {};
            this.instances = [];
        }
        return User;
    })();
    UI.User = User;
})(UI || (UI = {}));
