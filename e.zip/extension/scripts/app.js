var app = angular.module('UProxyExtension', ['angular-lodash', 'dependencyInjector']).config(function ($provide) {
    $provide.decorator('$sniffer', [
        '$delegate', function ($sniffer) {
            $sniffer.csp = true;
            return $sniffer;
        }]);
});

app.run([
    '$rootScope',
    'ui',
    'core',
    'model',
    function ($s, ui, core, model) {
        if (undefined === model) {
            console.error('model not found in dependency injections.');
        }
        $s.ui = ui;
        $s.core = core;
        $s.model = model;

        $s.ui['setRefreshHandler'](function () {
            $s.$apply(function () {
                console.log($s.ui['instance']);
                console.log('Refreshed the DOM!');
            });
        });

        $s.isOnline = function (network) {
            return (model.networks[network] && model.networks[network].online);
        };
        $s.isOffline = function (network) {
            return !$s.isOnline(network);
        };

        $s.resetState = function () {
            localStorage.clear();
            core.reset();
        };

        $s.prettyNetworkName = function (networkId) {
            switch (networkId) {
                case 'google':
                    return 'Google';
                case 'facebook':
                    return 'FB';
                case 'xmpp':
                    return 'XMPP';
                case 'websocket':
                    return 'websocket';
                default:
                    console.warn("No prettification for network: " + JSON.stringify(networkId));
            }
            return networkId;
        };
    }
]);

app.directive('uproxyConsent', function () {
    var link = function ($s, element, attrs) {
        $s.ProxyState = Consent.ProxyState;
        $s.ClientState = Consent.ClientState;
        var _modifyConsent = function (action) {
            console.log($s.currentProxyState(), $s.currentClientState());
            $s.core.modifyConsent({
                path: {
                    network: $s.ui['network'],
                    userId: $s.ui.user.userId,
                    instanceId: $s.ui.instance.instanceId
                },
                action: action
            });
        };

        $s.currentProxyState = function () {
            if (!$s.ui.instance) {
                return 'NONE';
            }
            return '' + $s.ProxyState[$s.ui.instance.consent.asProxy];
        };
        $s.currentClientState = function () {
            if (!$s.ui.instance) {
                return 'NONE';
            }
            return '' + $s.ClientState[$s.ui.instance.consent.asClient];
        };
    };
    return {
        restrict: 'E',
        templateUrl: 'templates/consent.html',
        link: link
    };
});

app.directive('uproxyConsentAction', function () {
    var link = function ($s, element, attrs) {
        $s.text = attrs['text'];

        $s.action = function () {
            var actionEnumStr = attrs['action'];
            var action = Consent.UserAction[actionEnumStr];
            $s.core.modifyConsent({
                path: {
                    network: $s.ui['network'],
                    userId: $s.ui.user.userId,
                    instanceId: $s.ui.instance.instanceId
                },
                action: action
            });
        };
        $s.hide = attrs['hide'];
        $s.disabled = attrs['disabled'];
    };
    return {
        restrict: 'E',
        templateUrl: 'templates/consent-action.html',
        link: link,
        scope: {}
    };
});

app.directive('uproxyProxyGadget', function () {
    var link = function ($s, element, attrs) {
        $s.start = $s.ui.startProxying;
        $s.stop = $s.ui.stopProxying;
    };
    return {
        restrict: 'E',
        templateUrl: 'templates/proxy-gadget.html',
        link: link
    };
});

app.directive('uproxyClientGadget', function () {
    var link = function ($s, element, attrs) {
    };
    return {
        restrict: 'E',
        templateUrl: 'templates/client-gadget.html',
        link: link
    };
});
