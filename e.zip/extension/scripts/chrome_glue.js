console.log('Loaded Chrome App-Extension Glue.');

var ChromeGlue;
(function (ChromeGlue) {
    ChromeGlue.CONNECT = 'connect';
    ChromeGlue.ACK = 'ack';

    
})(ChromeGlue || (ChromeGlue = {}));
