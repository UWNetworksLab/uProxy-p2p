// Initialize a 'default' state object here if desired. This file must exist,
// but doesn't need to do anything.
