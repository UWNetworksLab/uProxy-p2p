var ChromeNotifications = (function () {
    function ChromeNotifications() {
        this.ICON_DIR = 'icons/';
    }
    ChromeNotifications.prototype.setIcon = function (iconFile) {
        chrome.browserAction.setIcon({
            path: this.ICON_DIR + iconFile
        });
    };
    ChromeNotifications.prototype.setLabel = function (text) {
        chrome.browserAction.setBadgeText({ text: '' + text });
    };
    ChromeNotifications.prototype.setColor = function (color) {
        chrome.browserAction.setBadgeBackgroundColor({ color: color });
    };
    return ChromeNotifications;
})();
