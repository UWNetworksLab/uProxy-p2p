The server for the social router can be found at https://github.com/freedomjs/socialrouter
