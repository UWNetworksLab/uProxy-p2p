var Social;
(function (Social) {
    var PREFIX = 'SOCIAL-';
    Social.networks = {};

    function initializeNetworks() {
        for (var dependency in freedom) {
            if (freedom.hasOwnProperty(dependency)) {
                if (dependency.indexOf(PREFIX) !== 0 || 'social' !== freedom[dependency].api) {
                    continue;
                }

                var name = dependency.substr(PREFIX.length);
                var network = new Social.Network(name);
                Social.networks[name] = network;
            }
        }
        return Social.networks;
    }
    Social.initializeNetworks = initializeNetworks;

    function getNetwork(networkName) {
        if (!(networkName in Social.networks)) {
            console.warn('Network does not exist: ' + networkName);
            return null;
        }
        return Social.networks[networkName];
    }
    Social.getNetwork = getNetwork;

    var Network = (function () {
        function Network(name) {
            var _this = this;
            this.name = name;
            this.SaveKeys = {
                ME: 'me'
            };
            this.getStorePath = function () {
                return _this.name + '/';
            };
            this.login = function (remember) {
                if (typeof remember === "undefined") { remember = false; }
                if (_this.isLoginPending()) {
                    console.warn('Login already pending for ' + _this.name);
                    return Promise.reject();
                } else if (_this.isOnline()) {
                    console.warn('Already logged in to ' + _this.name);
                    return Promise.resolve();
                }

                var request = {
                    agent: 'uproxy',
                    version: '0.1',
                    url: 'https://github.com/uProxy/uProxy',
                    interactive: true,
                    rememberLogin: remember
                };
                _this.onceLoggedIn_ = _this.api.login(request).then(function (freedomClient) {
                    _this.myInstance.userId = freedomClient.userId;
                    _this.log('logged into uProxy');
                });
                return _this.onceLoggedIn_.then(_this.notifyUI).catch(function () {
                    _this.onceLoggedIn_ = null;
                    _this.error('Could not login.');
                    return Promise.reject(new Error('Could not login.'));
                });
            };
            this.logout = function () {
                if (!_this.isOnline()) {
                    console.warn('Already logged out of ' + _this.name);
                    return Promise.resolve();
                }
                _this.onceLoggedIn_ = null;
                return _this.api.logout().then(function () {
                    _this.myInstance.userId = null;
                    _this.log('logged out.');
                }).then(_this.notifyUI);
            };
            this.isOnline = function () {
                return Boolean(_this.myInstance && _this.myInstance.userId);
            };
            this.isLoginPending = function () {
                return Boolean(_this.onceLoggedIn_) && !_this.isOnline();
            };
            this.delayForLogin = function (handler) {
                return function (arg) {
                    if (!_this.onceLoggedIn_) {
                        _this.error('Not logged in.');
                        return;
                    }
                    return _this.onceLoggedIn_.then(function () {
                        handler(arg);
                    });
                };
            };
            this.prepareLocalInstance = function () {
                if (_this.myInstance) {
                    return Promise.resolve();
                }
                var key = _this.getStorePath() + _this.SaveKeys.ME;
                return storage.load(key).then(function (result) {
                    console.log(JSON.stringify(result));
                    _this.myInstance = new Core.LocalInstance(_this, result);
                    _this.log('loaded local instance from storage: ' + _this.myInstance.instanceId);
                    return _this.myInstance;
                }, function (e) {
                    _this.myInstance = new Core.LocalInstance(_this);
                    _this.log('generated new local instance: ' + _this.myInstance.instanceId);
                    return storage.save(key, _this.myInstance.serialize()).then(function (prev) {
                        _this.log('saved new local instance to storage');
                        return _this.myInstance;
                    });
                });
            };
            this.getLocalInstance = function () {
                return _this.myInstance;
            };
            this.notifyUI = function () {
                var payload = {
                    name: _this.name,
                    online: _this.isOnline()
                };
                ui.update(2001 /* NETWORK */, payload);
            };
            this.handleUserProfile = function (profile) {
                var userId = profile.userId;

                if (userId == _this.myInstance.userId) {
                    _this.log('<-- XMPP(self) [' + profile.name + ']\n' + profile);

                    _this.flushQueuedInstanceMessages();

                    ui.update(2002 /* USER_SELF */, {
                        network: _this.name,
                        user: profile
                    });
                    return;
                }

                _this.log('<--- XMPP(friend) [' + profile.name + ']' + profile);
                if (!(userId in _this.roster)) {
                    _this.addUser_(userId);
                }
                _this.getUser(userId).update(profile);
            };
            this.handleClientState = function (freedomClient) {
                var client = freedomClientToUproxyClient(freedomClient);
                if (client.userId == _this.myInstance.userId) {
                    _this.log('received own ClientState: ' + JSON.stringify(client));
                    return;
                }
                if (_this.isNewFriend_(client.userId)) {
                    _this.log('received ClientState for ' + client.userId + ' before UserProfile.');
                    _this.addUser_(client.userId);
                }
                _this.getUser(client.userId).handleClient(client);
            };
            this.handleMessage = function (incoming) {
                var userId = incoming.from.userId;
                if (_this.isNewFriend_(userId)) {
                    _this.log('received Message for ' + userId + ' before UserProfile.');
                    _this.addUser_(userId);
                }
                var msg = JSON.parse(incoming.message);
                _this.log('received <------ ' + incoming.message);
                _this.getUser(userId).handleMessage(incoming.from.clientId, msg);
            };
            this.addUser_ = function (userId) {
                if (!_this.isNewFriend_(userId)) {
                    _this.error(_this.name + ': cannot add already existing user!');
                    return;
                }
                _this.log('added "' + userId + '" to roster.');
                _this.roster[userId] = new Core.User(_this, userId);
            };
            this.isNewFriend_ = function (userId) {
                return !(userId == _this.myInstance.userId) && !(userId in _this.roster);
            };
            this.getUser = function (userId) {
                return _this.roster[userId];
            };
            this.getLocalInstanceId = function () {
                return _this.myInstance.instanceId;
            };
            this.getInstanceHandshake_ = function () {
                if (!_this.myInstance) {
                    throw Error('No local instance available!');
                }

                return {
                    type: 3000 /* INSTANCE */,
                    data: _this.myInstance.getInstanceHandshake()
                };
            };
            this.sendInstanceHandshake = function (clientId) {
                return _this.sendInstanceHandshakes_([clientId]);
            };
            this.flushQueuedInstanceMessages = function () {
                if (0 === _this.instanceMessageQueue_.length) {
                    return Promise.resolve();
                }
                return _this.sendInstanceHandshakes_(_this.instanceMessageQueue_).then(function () {
                    _this.instanceMessageQueue_ = [];
                });
            };
            this.sendInstanceHandshakes_ = function (clientIds) {
                var handshakes = [];
                var handshake = _this.getInstanceHandshake_();
                var cnt = clientIds.length;
                if (!handshake) {
                    throw Error('Not ready to send handshake');
                }
                clientIds.forEach(function (clientId) {
                    handshakes.push(_this.send(clientId, handshake));
                });
                return Promise.all(handshakes).then(function () {
                    _this.log('sent ' + cnt + ' instance handshake(s): ' + clientIds.join(', '));
                });
            };
            this.send = function (clientId, msg) {
                var msgString = JSON.stringify(msg);
                _this.log('sending ------> ' + msgString);
                return _this.api.sendMessage(clientId, msgString);
            };
            this.serialize = function () {
                return {
                    name: _this.name,
                    remember: false,
                    userIds: Object.keys(_this.roster)
                };
            };
            this.deserialize = function (json) {
                if (_this.name !== json.name) {
                    throw Error('Loading unexpected network name!' + json.name);
                }
                _this.remember = json.remember;

                for (var userId in json.userIds) {
                    storage.load(_this.getStorePath() + userId).then(function (json) {
                        _this.roster[userId] = new Core.User(_this, userId);
                        _this.roster[userId].deserialize(json);
                    }).catch(function (e) {
                        _this.error('could not load user ' + userId);
                    });
                }
            };
            this.log = function (msg) {
                console.log('[' + _this.name + '] ' + msg);
            };
            this.error = function (msg) {
                console.error('!!! [' + _this.name + '] ' + msg);
            };
            this.provider = freedom[PREFIX + name];
            this.metadata = this.provider.manifest;
            this.remember = false;
            this.roster = {};
            this.onceLoggedIn_ = null;
            this.instanceMessageQueue_ = [];
            this.api = this.provider();

            this.api.on('onUserProfile', this.delayForLogin(this.handleUserProfile));
            this.api.on('onClientState', this.delayForLogin(this.handleClientState));
            this.api.on('onMessage', this.delayForLogin(this.handleMessage));
            this.prepareLocalInstance().then(function () {
                _this.log('prepared Social.Network.');
                _this.notifyUI();
            });
        }
        return Network;
    })();
    Social.Network = Network;
})(Social || (Social = {}));

function freedomClientToUproxyClient(freedomClientState) {
    return {
        userId: freedomClientState.userId,
        clientId: freedomClientState.clientId,
        status: UProxyClient.Status[freedomClientState.status],
        timestamp: freedomClientState.timestamp
    };
}
