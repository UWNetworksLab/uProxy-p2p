var GOOGLE_TOKENINFO_URL = 'https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=';

var CLIENT_ID = '746567772449-jkm5q5hjqtpq5m9htg9kn0os8qphra4d.apps.googleusercontent.com';

var AuthGoogle = (function () {
    function AuthGoogle(credentialsCallback, errorCallback) {
        var _this = this;
        this.credentialsCallback = credentialsCallback;
        this.errorCallback = errorCallback;
        this.login = function (interactive) {
            _this.logout().then(function () {
                var googleOAuth2Url = 'https://accounts.google.com/o/oauth2/auth?' + 'response_type=token' + '&redirect_uri=' + chrome.identity.getRedirectURL() + '&client_id=' + CLIENT_ID + '&scope=email%20https://www.googleapis.com/auth/googletalk';
                console.log('googleOAuth2Url: ' + googleOAuth2Url);
                chrome.identity.launchWebAuthFlow({ url: googleOAuth2Url, interactive: true }, function (responseUrl) {
                    console.log('Got responseUrl: ' + responseUrl);
                    if (chrome.runtime.lastError) {
                        _this.errorCallback('Error logging into Google: ', chrome.runtime.lastError);
                        return;
                    }

                    var token = responseUrl.match(/access_token=([^&]+)/)[1];
                    console.log('Got Oauth2 token:' + token);
                    if (!token) {
                        _this.errorCallback('Error getting token for Google');
                        return;
                    }

                    _this.getCredentials_(token);
                });
            });
        };
        this.getCredentials_ = function (token) {
            var xhr = new XMLHttpRequest();
            xhr.addEventListener('load', function (evt) {
                if (xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);
                    var credentials = {
                        userId: response.email,
                        jid: response.email,
                        oauth2_token: token,
                        oauth2_auth: 'http://www.google.com/talk/protocol/auth',
                        host: 'talk.google.com'
                    };
                    if (_this.credentialsCallback) {
                        _this.credentialsCallback(credentials);
                    } else {
                        _this.errorCallback('Missing Google credentials callback');
                    }
                } else {
                    _this.errorCallback('Error validating Google oAuth token');
                }
            }, false);
            xhr.addEventListener('error', function (evt) {
                _this.errorCallback('Error occurred while validating Google oAuth token');
            }, false);
            xhr.open('get', GOOGLE_TOKENINFO_URL + token, true);
            xhr.send();
        };
        this.logout = function () {
            return new Promise(function (F, R) {
                console.log('About to log out of Google');
                chrome.identity.launchWebAuthFlow({ url: 'https://accounts.google.com/logout', interactive: false }, function (responseUrl) {
                    console.log('Successfully logged out of Google');
                    F();
                });
            });
        };
        this.login(true);
    }
    return AuthGoogle;
})();
