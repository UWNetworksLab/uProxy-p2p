var UPROXY_CHROME_EXTENSION_ID = 'pjpcdnccaekokkkeheolmpkfifcbibnj';

var installedFreedomHooks = [];
var uProxyAppChannel = freedom;

var ChromeUIConnector = (function () {
    function ChromeUIConnector() {
        var _this = this;
        this.onConnect_ = function (port) {
            if (UPROXY_CHROME_EXTENSION_ID !== port.sender.id || port.name !== 'uproxy-extension-to-app-port') {
                console.warn('Got connect from an unexpected extension id: ' + port.sender.id);
                return;
            }
            console.log('Connected to extension ' + UPROXY_CHROME_EXTENSION_ID);
            _this.extPort_ = port;

            _this.extPort_.postMessage(ChromeGlue.ACK);
            _this.extPort_.onMessage.addListener(_this.onExtMsg_);
        };
        this.onExtMsg_ = function (msg) {
            console.log('extension message: ', msg);
            var msgType = '' + msg.type;

            if ('emit' == msg.cmd) {
                uProxyAppChannel.emit(msgType, { data: msg.data, promiseId: msg.promiseId });
            } else if ('on' == msg.cmd) {
                if (installedFreedomHooks.indexOf(msg.type) >= 0) {
                    console.log('freedom already has a hook for ' + msg.type);
                    return;
                }
                installedFreedomHooks.push(msg.type);

                uProxyAppChannel.on(msgType, function (ret) {
                    _this.extPort_.postMessage({
                        cmd: 'fired',
                        type: msg.type,
                        data: ret
                    });
                });
            }
        };
        this.extPort_ = null;
        chrome.runtime.onConnectExternal.addListener(this.onConnect_);
    }
    return ChromeUIConnector;
})();
var connector = new ChromeUIConnector();
console.log('Starting uProxy app...');
