var Transport;
(function (Transport) {
    (function (Type) {
        Type[Type["SOCKS5"] = 0] = "SOCKS5";
        Type[Type["WEBRTC_SOCKS5"] = 1] = "WEBRTC_SOCKS5";
        Type[Type["TOR"] = 2] = "TOR";
        Type[Type["PSIPHON"] = 3] = "PSIPHON";
    })(Transport.Type || (Transport.Type = {}));
    var Type = Transport.Type;
})(Transport || (Transport = {}));
