
var View_oauth;

window.freedomcfg = function (register) {
    register('core.view', View_oauth);
};
