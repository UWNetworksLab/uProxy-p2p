var Core;
(function (Core) {
    var User = (function () {
        function User(network, userId) {
            var _this = this;
            this.network = network;
            this.userId = userId;
            this.getStorePath = function () {
                return _this.network.getStorePath() + _this.userId + '/';
            };
            this.update = function (profile) {
                if (profile.userId != _this.userId) {
                    throw Error('Updating User ' + _this.userId + ' with unexpected userID: ' + profile.userId);
                }
                _this.name = profile.name;
                _this.profile = profile;
                _this.log('Updating...');
                _this.notifyUI();
            };
            this.send = function (instanceId, payload) {
                if (!(instanceId in _this.instances_)) {
                    console.warn('Cannot send message to non-existing instance ' + instanceId);
                    return Promise.reject(new Error('Cannot send to invalid instance ' + instanceId));
                }
                var clientId = _this.instanceToClientMap_[instanceId];
                var promise = Promise.resolve(clientId);
                if (!clientId) {
                    if (!_this.reconnections_[instanceId]) {
                        promise = new Promise(function (F, R) {
                            _this.reconnections_[instanceId] = {
                                promise: promise,
                                fulfill: F
                            };
                        });
                    } else {
                        promise = _this.reconnections_[instanceId].promise;
                    }
                }
                return promise.then(function (clientId) {
                    clientId = _this.instanceToClientMap_[instanceId];
                    return _this.network.send(clientId, payload).then(function () {
                        return clientId;
                    });
                });
            };
            this.handleClient = function (client) {
                if (client.userId != _this.userId) {
                    console.error(_this.userId + 'received client with unexpected userId: ' + client.userId);
                    return;
                }
                _this.log('received client' + JSON.stringify(client));
                var clientIsNew = !(client.clientId in _this.clients);
                switch (client.status) {
                    case 1 /* ONLINE */:
                        _this.clients[client.clientId] = client.status;
                        if (clientIsNew) {
                            _this.network.sendInstanceHandshake(client.clientId);
                        }
                        break;
                    case 0 /* OFFLINE */:
                        _this.removeClient_(client.clientId);
                        break;
                    case 2 /* ONLINE_WITH_OTHER_APP */:
                        break;
                    default:
                        console.warn('Received client ' + client.clientId + ' with invalid status: (' + client.status + ')');
                        break;
                }
                _this.notifyUI();
            };
            this.handleMessage = function (clientId, msg) {
                if (!(clientId in _this.clients)) {
                    console.error(_this.userId + ' received message for non-existing client: ' + clientId);
                    return;
                }
                var msgType = msg.type;
                switch (msg.type) {
                    case 3000 /* INSTANCE */:
                        _this.syncInstance_(clientId, msg.data);
                        break;
                    case 3001 /* CONSENT */:
                        _this.handleConsent_(msg.data);
                        break;
                    case 3003 /* SIGNAL_FROM_CLIENT_PEER */:
                    case 3004 /* SIGNAL_FROM_SERVER_PEER */:
                        var instance = _this.getInstance(_this.clientToInstance(clientId));
                        if (!instance) {
                            console.error('failed to get instance for clientId ' + clientId);
                            return;
                        }
                        instance.handleSignal(msg.type, msg.data);
                        break;
                    default:
                        console.error(_this.userId + ' received invalid message.');
                }
            };
            this.getInstance = function (instanceId) {
                return _this.instances_[instanceId];
            };
            this.getLocalInstanceId = function () {
                return _this.network.getLocalInstanceId();
            };
            this.syncInstance_ = function (clientId, instance) {
                if (1 /* ONLINE */ !== _this.clients[clientId]) {
                    console.warn('Received an Instance Handshake from a non-uProxy client! ' + clientId);
                    return false;
                }
                _this.log('received instance' + JSON.stringify(instance));
                var instanceId = instance.instanceId;
                var oldClientId = _this.instanceToClientMap_[instance.instanceId];
                if (oldClientId) {
                    _this.clientToInstanceMap_[oldClientId] = null;
                }
                _this.clientToInstanceMap_[clientId] = instanceId;
                _this.instanceToClientMap_[instanceId] = clientId;

                var existingInstance = _this.instances_[instanceId];
                if (existingInstance) {
                    _this.fulfillReconnection_(instanceId);
                    existingInstance.update(instance);

                    existingInstance.sendConsent();
                } else {
                    _this.instances_[instanceId] = new Core.RemoteInstance(_this, instance);
                }

                _this.notifyUI();

                ui.syncInstance(_this.instances_[instanceId]);
                ui.syncMappings();
            };
            this.handleConsent_ = function (consentMessage) {
                var instanceId = consentMessage.instanceId;
                var instance = _this.instances_[instanceId];
                if (!instance) {
                    console.warn('Cannot update consent for non-existing instance!');
                    return;
                }
                instance.receiveConsent(consentMessage.consent);
            };
            this.fulfillReconnection_ = function (instanceId) {
                var newClientId = _this.instanceToClientMap_[instanceId];
                if (!newClientId) {
                    console.warn('Expected valid new clientId for ' + instanceId);

                    return;
                }
                var reconnect = _this.reconnections_[instanceId];
                if (reconnect) {
                    reconnect.fulfill(newClientId);
                }

                delete _this.reconnections_[instanceId];
            };
            this.clientToInstance = function (clientId) {
                return _this.clientToInstanceMap_[clientId];
            };
            this.instanceToClient = function (instanceId) {
                return _this.instanceToClientMap_[instanceId];
            };
            this.removeClient_ = function (clientId) {
                delete _this.clients[clientId];
                var instanceId = _this.clientToInstanceMap_[clientId];
                if (instanceId) {
                    delete _this.instanceToClientMap_[instanceId];
                }
                delete _this.clientToInstanceMap_[clientId];
            };
            this.notifyUI = function () {
                if ('pending' == _this.name) {
                    _this.log('Not showing UI without profile.');
                    return;
                }

                var instances = Object.keys(_this.instances_).map(function (instanceId) {
                    return _this.instances_[instanceId].serialize();
                });
                console.log(JSON.stringify(Object.keys(_this.instances_)));
                console.log(JSON.stringify(instances));

                ui.syncUser({
                    network: _this.network.name,
                    user: _this.profile,
                    clients: valuesOf(_this.clients),
                    instances: instances
                });
                _this.log('Sent myself to UI. \n' + JSON.stringify(_this.clientToInstanceMap_) + ' with ' + JSON.stringify(instances));
            };
            this.log = function (msg) {
                console.log('[User ' + _this.name + '] ' + msg);
            };
            this.serialize = function () {
                return {
                    userId: _this.userId,
                    name: _this.name,
                    instanceIds: Object.keys(_this.instances_)
                };
            };
            this.deserialize = function (json) {
                _this.userId = json.userId;
                _this.name = json.name;
                _this.instances_ = {};

                for (var instanceId in json.instanceIds) {
                    storage.load(_this.getStorePath() + instanceId).then(function (json) {
                        _this.instances_[instanceId] = new Core.RemoteInstance(_this, json);
                    }).catch(function (e) {
                        _this.log('could not load instance ' + instanceId);
                    });
                }
                _this.log('Loaded ' + Object.keys(_this.instances_).length + ' instances');
                _this.notifyUI();
            };
            console.log('New user: ' + userId);
            this.name = 'pending';
            this.profile = {
                userId: this.userId,
                timestamp: Date.now()
            };
            this.clients = {};
            this.instances_ = {};
            this.reconnections_ = {};
            this.clientToInstanceMap_ = {};
            this.instanceToClientMap_ = {};
        }
        return User;
    })();
    Core.User = User;
})(Core || (Core = {}));
