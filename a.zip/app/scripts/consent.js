var Consent;
(function (Consent) {
    

    (function (UserAction) {
        UserAction[UserAction["REQUEST"] = 5000] = "REQUEST";
        UserAction[UserAction["CANCEL_REQUEST"] = 5001] = "CANCEL_REQUEST";
        UserAction[UserAction["ACCEPT_OFFER"] = 5002] = "ACCEPT_OFFER";
        UserAction[UserAction["IGNORE_OFFER"] = 5003] = "IGNORE_OFFER";

        UserAction[UserAction["OFFER"] = 5100] = "OFFER";
        UserAction[UserAction["CANCEL_OFFER"] = 5101] = "CANCEL_OFFER";
        UserAction[UserAction["ALLOW_REQUEST"] = 5102] = "ALLOW_REQUEST";
        UserAction[UserAction["IGNORE_REQUEST"] = 5103] = "IGNORE_REQUEST";
    })(Consent.UserAction || (Consent.UserAction = {}));
    var UserAction = Consent.UserAction;

    (function (ClientState) {
        ClientState[ClientState["NONE"] = 6000] = "NONE";
        ClientState[ClientState["USER_OFFERED"] = 6001] = "USER_OFFERED";
        ClientState[ClientState["REMOTE_REQUESTED"] = 6002] = "REMOTE_REQUESTED";
        ClientState[ClientState["USER_IGNORED_REQUEST"] = 6003] = "USER_IGNORED_REQUEST";
        ClientState[ClientState["GRANTED"] = 6004] = "GRANTED";
    })(Consent.ClientState || (Consent.ClientState = {}));
    var ClientState = Consent.ClientState;
    (function (ClientState) {
        function userIsOffering(clientState) {
            switch (clientState) {
                case 6000 /* NONE */:
                case 6002 /* REMOTE_REQUESTED */:
                case 6003 /* USER_IGNORED_REQUEST */:
                    return false;
                case 6001 /* USER_OFFERED */:
                case 6004 /* GRANTED */:
                    return true;
            }
        }
        ClientState.userIsOffering = userIsOffering;
        function remoteIsRequesting(clientState) {
            switch (clientState) {
                case 6000 /* NONE */:
                case 6001 /* USER_OFFERED */:
                    return false;
                case 6003 /* USER_IGNORED_REQUEST */:
                case 6002 /* REMOTE_REQUESTED */:
                case 6004 /* GRANTED */:
                    return true;
            }
        }
        ClientState.remoteIsRequesting = remoteIsRequesting;
    })(Consent.ClientState || (Consent.ClientState = {}));
    var ClientState = Consent.ClientState;

    (function (ProxyState) {
        ProxyState[ProxyState["NONE"] = 6100] = "NONE";
        ProxyState[ProxyState["USER_REQUESTED"] = 6101] = "USER_REQUESTED";
        ProxyState[ProxyState["REMOTE_OFFERED"] = 6102] = "REMOTE_OFFERED";
        ProxyState[ProxyState["USER_IGNORED_OFFER"] = 6103] = "USER_IGNORED_OFFER";
        ProxyState[ProxyState["GRANTED"] = 6104] = "GRANTED";
    })(Consent.ProxyState || (Consent.ProxyState = {}));
    var ProxyState = Consent.ProxyState;
    (function (ProxyState) {
        function userIsRequesting(proxyState) {
            switch (proxyState) {
                case 6100 /* NONE */:
                case 6102 /* REMOTE_OFFERED */:
                case 6103 /* USER_IGNORED_OFFER */:
                    return false;
                case 6101 /* USER_REQUESTED */:
                case 6104 /* GRANTED */:
                    return true;
            }
        }
        ProxyState.userIsRequesting = userIsRequesting;
        function remoteIsOffering(proxyState) {
            switch (proxyState) {
                case 6100 /* NONE */:
                case 6101 /* USER_REQUESTED */:
                    return false;
                case 6103 /* USER_IGNORED_OFFER */:
                case 6102 /* REMOTE_OFFERED */:
                case 6104 /* GRANTED */:
                    return true;
            }
        }
        ProxyState.remoteIsOffering = remoteIsOffering;
    })(Consent.ProxyState || (Consent.ProxyState = {}));
    var ProxyState = Consent.ProxyState;
})(Consent || (Consent = {}));

var Consent;
(function (Consent) {
    var fsm = new FSM();
    var S = Consent.ProxyState;
    var A = Consent.UserAction;
    fsm.set(6100 /* NONE */, 5000 /* REQUEST */, 6101 /* USER_REQUESTED */);
    fsm.set(6101 /* USER_REQUESTED */, 5001 /* CANCEL_REQUEST */, 6100 /* NONE */);
    fsm.set(6102 /* REMOTE_OFFERED */, 5000 /* REQUEST */, 6104 /* GRANTED */);
    fsm.set(6102 /* REMOTE_OFFERED */, 5002 /* ACCEPT_OFFER */, 6104 /* GRANTED */);
    fsm.set(6102 /* REMOTE_OFFERED */, 5003 /* IGNORE_OFFER */, 6103 /* USER_IGNORED_OFFER */);
    fsm.set(6103 /* USER_IGNORED_OFFER */, 5002 /* ACCEPT_OFFER */, 6104 /* GRANTED */);
    fsm.set(6104 /* GRANTED */, 5001 /* CANCEL_REQUEST */, 6102 /* REMOTE_OFFERED */);
    function userActionOnProxyState(action, state) {
        return fsm.get(state, action);
    }
    Consent.userActionOnProxyState = userActionOnProxyState;
})(Consent || (Consent = {}));

var Consent;
(function (Consent) {
    var fsm = new FSM();
    var S = Consent.ClientState;
    var A = Consent.UserAction;
    fsm.set(6000 /* NONE */, 5100 /* OFFER */, 6001 /* USER_OFFERED */);
    fsm.set(6001 /* USER_OFFERED */, 5101 /* CANCEL_OFFER */, 6000 /* NONE */);
    fsm.set(6002 /* REMOTE_REQUESTED */, 5100 /* OFFER */, 6004 /* GRANTED */);
    fsm.set(6002 /* REMOTE_REQUESTED */, 5102 /* ALLOW_REQUEST */, 6004 /* GRANTED */);
    fsm.set(6002 /* REMOTE_REQUESTED */, 5103 /* IGNORE_REQUEST */, 6003 /* USER_IGNORED_REQUEST */);
    fsm.set(6003 /* USER_IGNORED_REQUEST */, 5102 /* ALLOW_REQUEST */, 6004 /* GRANTED */);
    fsm.set(6004 /* GRANTED */, 5101 /* CANCEL_OFFER */, 6002 /* REMOTE_REQUESTED */);
    function userActionOnClientState(action, state) {
        return fsm.get(state, action);
    }
    Consent.userActionOnClientState = userActionOnClientState;
})(Consent || (Consent = {}));

var Consent;
(function (Consent) {
    var fsm = new FSM();

    fsm.set(6100 /* NONE */, 0, 6100 /* NONE */);
    fsm.set(6100 /* NONE */, 1, 6102 /* REMOTE_OFFERED */);

    fsm.set(6102 /* REMOTE_OFFERED */, 0, 6100 /* NONE */);
    fsm.set(6102 /* REMOTE_OFFERED */, 1, 6102 /* REMOTE_OFFERED */);

    fsm.set(6101 /* USER_REQUESTED */, 0, 6101 /* USER_REQUESTED */);
    fsm.set(6101 /* USER_REQUESTED */, 1, 6104 /* GRANTED */);

    fsm.set(6103 /* USER_IGNORED_OFFER */, 0, 6100 /* NONE */);
    fsm.set(6103 /* USER_IGNORED_OFFER */, 1, 6103 /* USER_IGNORED_OFFER */);

    fsm.set(6104 /* GRANTED */, 0, 6101 /* USER_REQUESTED */);
    fsm.set(6104 /* GRANTED */, 1, 6104 /* GRANTED */);

    function updateProxyStateFromRemoteState(remoteState, state) {
        return fsm.get(state, +remoteState.isOffering);
    }
    Consent.updateProxyStateFromRemoteState = updateProxyStateFromRemoteState;
})(Consent || (Consent = {}));

var Consent;
(function (Consent) {
    var fsm = new FSM();

    fsm.set(6000 /* NONE */, 0, 6000 /* NONE */);
    fsm.set(6000 /* NONE */, 1, 6002 /* REMOTE_REQUESTED */);

    fsm.set(6002 /* REMOTE_REQUESTED */, 0, 6000 /* NONE */);
    fsm.set(6002 /* REMOTE_REQUESTED */, 1, 6002 /* REMOTE_REQUESTED */);

    fsm.set(6001 /* USER_OFFERED */, 0, 6001 /* USER_OFFERED */);
    fsm.set(6001 /* USER_OFFERED */, 1, 6004 /* GRANTED */);

    fsm.set(6003 /* USER_IGNORED_REQUEST */, 0, 6000 /* NONE */);
    fsm.set(6003 /* USER_IGNORED_REQUEST */, 1, 6003 /* USER_IGNORED_REQUEST */);

    fsm.set(6004 /* GRANTED */, 0, 6001 /* USER_OFFERED */);
    fsm.set(6004 /* GRANTED */, 1, 6004 /* GRANTED */);

    function updateClientStateFromRemoteState(remoteState, state) {
        return fsm.get(state, +remoteState.isRequesting);
    }
    Consent.updateClientStateFromRemoteState = updateClientStateFromRemoteState;
})(Consent || (Consent = {}));
