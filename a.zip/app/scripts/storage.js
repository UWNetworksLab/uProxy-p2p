var Core;
(function (Core) {
    var fStorage = freedom['storage']();

    Core.DEBUG_STATESTORAGE = true;

    

    var Storage = (function () {
        function Storage() {
            var _this = this;
            this.reset = function () {
                return fStorage.clear().then(function () {
                    dbg('Cleared all keys from storage.');
                });
            };
            this.load = function (key) {
                _this.log('loading ' + key);
                return fStorage.get(key).then(function (result) {
                    _this.log('Loaded [' + key + '] : ' + result);
                    return JSON.parse(result);
                }, function (e) {
                    _this.log(e.message);
                    return {};
                });
            };
            this.save = function (key, val) {
                _this.log('Saving ' + key + ': ' + val);
                return fStorage.set(key, JSON.stringify(val)).then(function (prev) {
                    _this.log('Saved to storage[' + key + ']. old val=' + prev);
                    if (!prev) {
                        return undefined;
                    }
                    return JSON.parse(prev);
                }).catch(function (e) {
                    _this.log(e.message);
                    return {};
                });
            };
            this.log = function (msg) {
                if (Core.DEBUG_STATESTORAGE) {
                    console.log('[Storage] ' + msg);
                }
            };
        }
        return Storage;
    })();
    Core.Storage = Storage;

    var modulePrefix_ = '[Storage] ';
    var dbg = function () {
        var args = [];
        for (var _i = 0; _i < (arguments.length - 0); _i++) {
            args[_i] = arguments[_i + 0];
        }
        dbg_(console.log, args);
    };
    var dbgWarn = function () {
        var args = [];
        for (var _i = 0; _i < (arguments.length - 0); _i++) {
            args[_i] = arguments[_i + 0];
        }
        dbg_(console.warn);
    };
    var dbgErr = function () {
        var args = [];
        for (var _i = 0; _i < (arguments.length - 0); _i++) {
            args[_i] = arguments[_i + 0];
        }
        dbg(console.error);
    };
    var dbg_ = function (logger) {
        var args = [];
        for (var _i = 0; _i < (arguments.length - 1); _i++) {
            args[_i] = arguments[_i + 1];
        }
        if (!Core.DEBUG_STATESTORAGE) {
            return;
        }
        logger.apply(Core, [modulePrefix_].concat(args));
    };
})(Core || (Core = {}));
