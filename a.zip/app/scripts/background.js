function launchDebugWindow(launchData) {
    chrome.app.window.create('debug.html', {
        id: 'uproxy',
        minWidth: 640,
        minHeight: 480
    });
}
chrome.app.runtime.onLaunched.addListener(launchDebugWindow);
