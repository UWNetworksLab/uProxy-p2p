var uProxy;
(function (uProxy) {
    (function (Command) {
        Command[Command["READY"] = 1000] = "READY";
        Command[Command["REFRESH"] = 1001] = "REFRESH";
        Command[Command["RESET"] = 1002] = "RESET";
        Command[Command["LOGIN"] = 1003] = "LOGIN";
        Command[Command["LOGOUT"] = 1004] = "LOGOUT";
        Command[Command["SEND_INSTANCE"] = 1005] = "SEND_INSTANCE";
        Command[Command["INVITE"] = 1006] = "INVITE";
        Command[Command["CHANGE_OPTION"] = 1007] = "CHANGE_OPTION";
        Command[Command["UPDATE_DESCRIPTION"] = 1008] = "UPDATE_DESCRIPTION";
        Command[Command["DISMISS_NOTIFICATION"] = 1009] = "DISMISS_NOTIFICATION";
        Command[Command["START_PROXYING"] = 1010] = "START_PROXYING";
        Command[Command["STOP_PROXYING"] = 1011] = "STOP_PROXYING";
        Command[Command["MODIFY_CONSENT"] = 1012] = "MODIFY_CONSENT";
    })(uProxy.Command || (uProxy.Command = {}));
    var Command = uProxy.Command;

    (function (Update) {
        Update[Update["ALL"] = 2000] = "ALL";
        Update[Update["NETWORK"] = 2001] = "NETWORK";
        Update[Update["USER_SELF"] = 2002] = "USER_SELF";
        Update[Update["USER_FRIEND"] = 2003] = "USER_FRIEND";
        Update[Update["CLIENT"] = 2004] = "CLIENT";
        Update[Update["INSTANCE"] = 2005] = "INSTANCE";
        Update[Update["DESCRIPTION"] = 2006] = "DESCRIPTION";
        Update[Update["ID_MAPS"] = 2007] = "ID_MAPS";
        Update[Update["COMMAND_FULFILLED"] = 2008] = "COMMAND_FULFILLED";
        Update[Update["COMMAND_REJECTED"] = 2009] = "COMMAND_REJECTED";
    })(uProxy.Update || (uProxy.Update = {}));
    var Update = uProxy.Update;

    (function (MessageType) {
        MessageType[MessageType["INSTANCE"] = 3000] = "INSTANCE";
        MessageType[MessageType["CONSENT"] = 3001] = "CONSENT";
        MessageType[MessageType["DESCRIPTION"] = 3002] = "DESCRIPTION";

        MessageType[MessageType["SIGNAL_FROM_CLIENT_PEER"] = 3003] = "SIGNAL_FROM_CLIENT_PEER";
        MessageType[MessageType["SIGNAL_FROM_SERVER_PEER"] = 3004] = "SIGNAL_FROM_SERVER_PEER";
    })(uProxy.MessageType || (uProxy.MessageType = {}));
    var MessageType = uProxy.MessageType;

    

    

    

    
})(uProxy || (uProxy = {}));

var UProxyClient;
(function (UProxyClient) {
    (function (Status) {
        Status[Status["OFFLINE"] = 0] = "OFFLINE";

        Status[Status["ONLINE"] = 1] = "ONLINE";

        Status[Status["ONLINE_WITH_OTHER_APP"] = 2] = "ONLINE_WITH_OTHER_APP";
    })(UProxyClient.Status || (UProxyClient.Status = {}));
    var Status = UProxyClient.Status;

    
})(UProxyClient || (UProxyClient = {}));

