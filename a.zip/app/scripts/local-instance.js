var Core;
(function (Core) {
    var LocalInstance = (function () {
        function LocalInstance(network, load) {
            var _this = this;
            this.network = network;
            this.getStorePath = function () {
                return _this.network.getStorePath() + 'me/';
            };
            this.generateKeyHash = function () {
                var keyHash = '';
                var hex;
                for (var i = 0; i < 20; i++) {
                    hex = Math.floor(Math.random() * 256).toString(16);
                    keyHash = ((i > 0) ? (keyHash + ':') : '') + ('00'.substr(0, 2 - hex.length) + hex);
                }
                return keyHash;
            };
            this.generateRandomDescription_ = function () {
                var words = [];

                for (var i = 0; i < 4; i++) {
                    var index = Math.floor(Math.random() * 256);
                    words.push((i & 1) ? nouns[index] : adjectives[index]);
                }
                return words.join(' ');
            };
            this.updateDescription = function (description) {
                _this.description = description;
            };
            this.getInstanceHandshake = function () {
                return {
                    instanceId: _this.instanceId,
                    keyHash: _this.keyHash,
                    description: _this.description
                };
            };
            this.serialize = function () {
                return {
                    instanceId: _this.instanceId,
                    description: _this.description,
                    keyHash: _this.keyHash
                };
            };
            this.deserialize = function (json) {
                _this.instanceId = json.instanceId;
                _this.description = json.description;
                _this.keyHash = json.keyHash;
            };
            if (load) {
                this.deserialize(load);
                return;
            }
            this.instanceId = LocalInstance.generateInstanceID();
            this.description = this.generateRandomDescription_();
            this.keyHash = this.generateKeyHash();
            console.log('Generated LocalInstance: ', this.instanceId, this.description, this.keyHash);
        }
        LocalInstance.generateInstanceID = function () {
            var hex, id = '';

            for (var i = 0; i < 20; i++) {
                hex = Math.floor(Math.random() * 256).toString(16);
                id += ('00'.substr(0, 2 - hex.length) + hex);
            }
            return id;
        };
        return LocalInstance;
    })();
    Core.LocalInstance = LocalInstance;
})(Core || (Core = {}));
