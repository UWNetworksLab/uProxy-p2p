console.log('Uproxy backend, running in worker ' + self.location.href);

rtcToNetServer.emit('start');


bgAppPageChannel.emit('ready', null);
