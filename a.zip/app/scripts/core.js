var storage = new Core.Storage();

var bgAppPageChannel = freedom;

var socksToRtcClient = freedom['SocksToRtc']();
var rtcToNetServer = freedom['RtcToNet']();

var proxy = null;

var UIConnector = (function () {
    function UIConnector() {
        var _this = this;
        this.update = function (type, data) {
            switch (type) {
                case 2000 /* ALL */:
                    var networkName;
                    for (networkName in Social.networks) {
                        Social.networks[networkName].notifyUI();
                    }
                    break;

                case 2001 /* NETWORK */:
                    console.log('update [NETWORK]', data);
                    break;

                case 2002 /* USER_SELF */:
                case 2003 /* USER_FRIEND */:
                    console.log('update [USER]', data);
                    break;

                case 2008 /* COMMAND_FULFILLED */:
                    console.log('update [COMMAND_FULFILLED]', data);
                    break;

                case 2009 /* COMMAND_REJECTED */:
                    console.log('update [COMMAND_REJECTED]', data);
                    break;

                default:
                    console.warn('Not yet implemented.');
                    return;
            }
            bgAppPageChannel.emit('' + type, data);
        };
        this.syncInstance = function (instance, field) {
        };
        this.syncMappings = function () {
        };
        this.sync = function () {
            console.log('sending ALL state to UI.');
            ui.update(2000 /* ALL */);
        };
        this.syncUser = function (payload) {
            console.log('Core: UI.syncUser ' + JSON.stringify(payload));
            _this.update(2003 /* USER_FRIEND */, payload);
        };
        this.refreshDOM = function () {
            console.error('Cannot refresh DOM from the Core.');
        };
    }
    return UIConnector;
})();
var ui = new UIConnector();

var Core;
(function (Core) {
    Core.reset = function () {
        console.log('reset');
        for (var network in Social.networks) {
            Social.networks[network].logout();
        }
        storage.reset().then(ui.sync);
    };

    Core.onCommand = function (cmd, handler) {
        bgAppPageChannel.on('' + cmd, function (args) {
            handler(args.data);
        });
    };

    Core.onPromiseCommand = function (cmd, handler) {
        var promiseCommandHandler = function (args) {
            if (!args.promiseId) {
                console.error('onPromiseCommand called for cmd ' + cmd + 'with promiseId undefined');
                return Promise.reject();
            }

            handler(args.data).then(function () {
                ui.update(2008 /* COMMAND_FULFILLED */, args.promiseId);
            }, function () {
                ui.update(2009 /* COMMAND_REJECTED */, args.promiseId);
            });
        };
        bgAppPageChannel.on('' + cmd, promiseCommandHandler);
    };

    Core.login = function (networkName) {
        var network = Social.getNetwork(networkName);
        if (null === network) {
            console.warn('Could not login to ' + networkName);
            return Promise.reject();
        }
        var loginPromise = network.login(true);
        loginPromise.then(ui.sync).then(function () {
            console.log('Successfully logged in to ' + networkName);
        });

        return loginPromise;
    };

    Core.logout = function (networkName) {
        var network = Social.getNetwork(networkName);
        if (null === network) {
            console.warn('Could not logout of ' + networkName);
            return;
        }
        network.logout().then(function () {
            console.log('Successfully logged out of ' + networkName);
        });

        ui.syncMappings();
    };

    Core.updateDescription = function (description) {
        for (var network in Social.networks) {
            var myself = Social.networks[network].getLocalInstance();
            if (!myself) {
                console.error('No LocalInstance to set description for!');
                return;
            }
            myself.updateDescription(description);
        }
    };

    Core.modifyConsent = function (command) {
        var instance = Core.getInstance(command.path);
        if (!instance) {
            console.error('Cannot modify consent for non-existing instance!');
            return;
        }

        instance.modifyConsent(command.action);
    };

    Core.start = function (path) {
        if (proxy) {
            console.log('Existing proxying session! Terminating...');
            Core.stop();
            proxy = null;
        }
        var remote = Core.getInstance(path);
        if (!remote) {
            console.error('Instance ' + path.instanceId + ' does not exist for proxying.');
            return Promise.reject();
        }

        return remote.start().then(function () {
            proxy = remote;
        });
    };

    Core.stop = function () {
        if (!proxy) {
            console.error('Cannot stop proxying when there is no proxy');
        }
        proxy.stop();
        proxy = null;
    };

    Core.getInstance = function (path) {
        var network = Social.getNetwork(path.network);
        if (!network) {
            console.error('No network ' + path.network);
            return;
        }
        var user = network.getUser(path.userId);
        if (!user) {
            console.error('No user ' + path.userId);
            return;
        }
        return user.getInstance(path.instanceId);
    };
})(Core || (Core = {}));

var networks = Social.initializeNetworks();

socksToRtcClient.on('sendSignalToPeer', function (signalFromSocksRtc) {
    console.log('client(sendSignalToPeer):' + JSON.stringify(signalFromSocksRtc));

    var localPeerId = JSON.parse(signalFromSocksRtc.peerId);
    var instance = Core.getInstance(localPeerId.serverInstancePath);
    if (!instance) {
        console.error('Cannot send client signal to non-existing RemoteInstance.');
        return;
    }

    var localInstanceId = instance.user.getLocalInstanceId();
    var sharedSignal = {
        peerId: localInstanceId,
        data: signalFromSocksRtc.data
    };
    console.log('client(sendSignalToPeer): sending sharedSignal ' + JSON.stringify(sharedSignal));
    instance.send({
        type: 3003 /* SIGNAL_FROM_CLIENT_PEER */,
        data: sharedSignal
    });
});

socksToRtcClient.on('socksToRtcSuccess', function (peerInfo) {
    var localPeerId = JSON.parse(peerInfo.peerId);
    var instance = Core.getInstance(localPeerId.serverInstancePath);
    if (!instance) {
        console.error('socksToRtcSuccess: RemoteInstance not found.', peerInfo);
        return;
    }
    instance.handleStartSuccess();
});

socksToRtcClient.on('socksToRtcFailure', function (peerInfo) {
    var localPeerId = JSON.parse(peerInfo.peerId);
    var instance = Core.getInstance(localPeerId.serverInstancePath);
    if (!instance) {
        console.error('socksToRtcFailure: RemoteInstance not found.', peerInfo);
        return;
    }
    instance.handleStartFailure();
});

rtcToNetServer.on('sendSignalToPeer', function (signalFromSocksRtc) {
    console.log('server(sendSignalToPeer):' + JSON.stringify(signalFromSocksRtc));

    var localPeerId = JSON.parse(signalFromSocksRtc.peerId);
    var instance = Core.getInstance(localPeerId.clientInstancePath);
    if (!instance) {
        console.error('Cannot send server signal to non-existing peer.');
        return;
    }

    var localInstanceId = instance.user.getLocalInstanceId();
    var sharedSignal = {
        peerId: localInstanceId,
        data: signalFromSocksRtc.data
    };
    console.log('server(sendSignalToPeer): sending sharedSignal ' + JSON.stringify(sharedSignal));
    instance.send({
        type: 3004 /* SIGNAL_FROM_SERVER_PEER */,
        data: sharedSignal
    });
});

function _validateKeyHash(keyHash) {
    console.log('Warning: keyHash Validation not yet implemented...');
    return true;
}

Core.onCommand(1000 /* READY */, ui.sync);
Core.onCommand(1002 /* RESET */, Core.reset);

Core.onPromiseCommand(1003 /* LOGIN */, Core.login);
Core.onCommand(1004 /* LOGOUT */, Core.logout);

Core.onCommand(1012 /* MODIFY_CONSENT */, Core.modifyConsent);

Core.onPromiseCommand(1010 /* START_PROXYING */, Core.start);
Core.onCommand(1011 /* STOP_PROXYING */, Core.stop);

Core.onCommand(1007 /* CHANGE_OPTION */, function (data) {
    console.warn('CHANGE_OPTION yet to be implemented!');
});

Core.onCommand(1008 /* UPDATE_DESCRIPTION */, Core.updateDescription);
Core.onCommand(1009 /* DISMISS_NOTIFICATION */, function (userId) {
});

Core.onCommand(1006 /* INVITE */, function (userId) {
});
