var Core;
(function (Core) {
    var RemoteInstance = (function () {
        function RemoteInstance(user, data) {
            var _this = this;
            this.user = user;
            this.consent = {
                asClient: 6000 /* NONE */,
                asProxy: 6100 /* NONE */
            };
            this.access = {
                asClient: false,
                asProxy: false
            };
            this.fulfillStartRequest_ = null;
            this.rejectStartRequest_ = null;
            this.getStorePath = function () {
                return _this.user.getStorePath() + _this.instanceId;
            };
            this.send = function (msg) {
                _this.user.send(_this.instanceId, msg);
            };
            this.handleSignal = function (type, signalFromWire) {
                var isLocalServer = (type == 3003 /* SIGNAL_FROM_CLIENT_PEER */);
                var localPeerId = _this.getLocalPeerId(isLocalServer);
                var signalForSocksRtc = {
                    peerId: JSON.stringify(localPeerId),
                    data: signalFromWire.data
                };

                switch (type) {
                    case 3003 /* SIGNAL_FROM_CLIENT_PEER */:
                        rtcToNetServer.emit('handleSignalFromPeer', signalForSocksRtc);
                        break;
                    case 3004 /* SIGNAL_FROM_SERVER_PEER */:
                        socksToRtcClient.emit('handleSignalFromPeer', signalForSocksRtc);
                        break;
                    default:
                        console.warn('Invalid signal! ' + uProxy.MessageType[type]);
                        return;
                }
            };
            this.start = function () {
                if (6104 /* GRANTED */ !== _this.consent.asProxy) {
                    console.warn('Lacking permission to proxy!');
                    return Promise.reject();
                } else if (_this.access.asProxy) {
                    console.warn('Already proxying through ' + _this.instanceId);
                    return Promise.reject();
                } else if (_this.fulfillStartRequest_ || _this.rejectStartRequest_) {
                    console.warn('Already waiting for proxy to start ' + _this.instanceId);
                    return Promise.reject();
                }

                var localPeerId = _this.getLocalPeerId(false);
                console.log('starting client with localPeerId: ' + JSON.stringify(localPeerId));
                socksToRtcClient.emit('start', {
                    'host': '127.0.0.1', 'port': 9999,
                    'peerId': JSON.stringify(localPeerId)
                });
                return new Promise(function (F, R) {
                    _this.fulfillStartRequest_ = F;
                    _this.rejectStartRequest_ = R;
                }).then(function () {
                    console.log('Proxy now ready through ' + _this.user.userId);
                    _this.fulfillStartRequest_ = null;
                    _this.rejectStartRequest_ = null;
                    _this.access.asProxy = true;
                    _this.user.notifyUI();
                }).catch(function () {
                    console.error('Could not start proxy through ' + _this.user.userId);
                    _this.fulfillStartRequest_ = null;
                    _this.rejectStartRequest_ = null;
                    return Promise.reject();
                });
            };
            this.handleStartSuccess = function () {
                if (!_this.fulfillStartRequest_) {
                    console.error('No fulfillStartRequest_ for handleStartSuccess');
                    return;
                }
                _this.fulfillStartRequest_();
            };
            this.handleStartFailure = function () {
                if (!_this.rejectStartRequest_) {
                    console.error('No rejectStartRequest_ for handleStartSuccess');
                    return;
                }
                _this.rejectStartRequest_();
            };
            this.stop = function () {
                if (!_this.access.asProxy) {
                    console.error('Cannot stop proxying when not proxying.');
                    return;
                }
                socksToRtcClient.emit('stop');
                _this.access.asProxy = false;
                _this.user.notifyUI();
            };
            this.update = function (data) {
                _this.instanceId = data.instanceId;
                _this.keyHash = data.keyHash;
                _this.description = data.description;
            };
            this.modifyConsent = function (action) {
                switch (action) {
                    case 5000 /* REQUEST */:
                    case 5001 /* CANCEL_REQUEST */:
                    case 5002 /* ACCEPT_OFFER */:
                    case 5003 /* IGNORE_OFFER */:
                        var newProxyConsent = Consent.userActionOnProxyState(action, _this.consent.asProxy);
                        if (newProxyConsent) {
                            _this.consent.asProxy = newProxyConsent;
                        } else {
                            console.warn('Invalid proxy consent transition!', _this.consent.asProxy, action);
                            return;
                        }
                        break;

                    case 5100 /* OFFER */:
                    case 5101 /* CANCEL_OFFER */:
                    case 5102 /* ALLOW_REQUEST */:
                    case 5103 /* IGNORE_REQUEST */:
                        var newClientConsent = Consent.userActionOnClientState(action, _this.consent.asClient);
                        if (newClientConsent) {
                            _this.consent.asClient = newClientConsent;
                        } else {
                            console.warn('Invalid client consent transition!', _this.consent.asClient, action);
                            return;
                        }
                        break;
                    default:
                        console.warn('Invalid Consent.UserAction! ' + action);
                        return;
                }

                _this.sendConsent();
                _this.saveToStorage();

                _this.user.notifyUI();
            };
            this.sendConsent = function () {
                var consentPayload = {
                    type: 3001 /* CONSENT */,
                    data: {
                        instanceId: _this.user.getLocalInstanceId(),
                        consent: _this.getConsentBits()
                    }
                };
                _this.send(consentPayload);
            };
            this.receiveConsent = function (bits) {
                _this.consent.asProxy = Consent.updateProxyStateFromRemoteState(bits, _this.consent.asProxy);
                _this.consent.asClient = Consent.updateClientStateFromRemoteState(bits, _this.consent.asClient);
                _this.saveToStorage();

                _this.user.notifyUI();
            };
            this.getConsentBits = function () {
                return {
                    isRequesting: Consent.ProxyState.userIsRequesting(_this.consent.asProxy),
                    isOffering: Consent.ClientState.userIsOffering(_this.consent.asClient)
                };
            };
            this.saveToStorage = function () {
                var json = _this.serialize();
                storage.save(_this.getStorePath(), json).then(function (old) {
                    console.log('Saved instance ' + _this.instanceId + ' to storage.');
                });
            };
            this.serialize = function () {
                return {
                    instanceId: _this.instanceId,
                    description: _this.description,
                    keyHash: _this.keyHash,
                    consent: _this.consent,
                    access: _this.access
                };
            };
            this.deserialize = function (json) {
                _this.instanceId = json.instanceId, _this.description = json.description, _this.keyHash = json.keyHash, _this.consent = json.consent, _this.access = json.access;
            };
            this.getLocalPeerId = function (isLocalServer) {
                var network = _this.user.network;
                var localInstancePath = {
                    network: network.name,
                    userId: network.myInstance.userId,
                    instanceId: network.myInstance.instanceId
                };
                var remoteInstancePath = {
                    network: network.name,
                    userId: _this.user.userId,
                    instanceId: _this.instanceId
                };

                if (isLocalServer) {
                    return {
                        clientInstancePath: remoteInstancePath,
                        serverInstancePath: localInstancePath
                    };
                } else {
                    return {
                        clientInstancePath: localInstancePath,
                        serverInstancePath: remoteInstancePath
                    };
                }
            };
            this.update(data);

            if (data.consent) {
                this.consent = data.consent;
            }
        }
        return RemoteInstance;
    })();
    Core.RemoteInstance = RemoteInstance;

    (function (ObfuscationType) {
        ObfuscationType[ObfuscationType["NONE"] = 0] = "NONE";
        ObfuscationType[ObfuscationType["RANDOM1"] = 1] = "RANDOM1";
    })(Core.ObfuscationType || (Core.ObfuscationType = {}));
    var ObfuscationType = Core.ObfuscationType;
})(Core || (Core = {}));
